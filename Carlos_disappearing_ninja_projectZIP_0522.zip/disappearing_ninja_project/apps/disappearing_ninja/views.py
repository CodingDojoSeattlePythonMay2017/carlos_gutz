from django.shortcuts import render, redirect

# Create your views here.


def index(request):
    return render(request, "disappearing_ninja/index.html")


def ninjas(request):
    return render(request, "disappearing_ninja/ninjashere.html")


def ninjacolors(request, color):
    if color == "blue":
        ninja = "disappearing_ninja/images/leonardo.jpeg"
    elif color == "red":
        ninja = "disappearing_ninja/images/raphael.jpeg"
    elif color == "purple":
        ninja = "disappearing_ninja/images/donny.jpeg"
    elif color == "orange":
        ninja = "disappearing_ninja/images/mikey.jpeg"
    else:
        ninja = "disappearing_ninja/images/april.jpeg"

    context = {
        "color": ninja
    }

    return render(request, "disappearing_ninja/single_ninja.html", context)
