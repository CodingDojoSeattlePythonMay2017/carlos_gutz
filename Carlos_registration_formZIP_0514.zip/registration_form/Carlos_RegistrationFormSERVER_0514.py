#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, redirect, flash
import re
from time import strftime


EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
upper_checker = re.compile(r"[A-Z]")
number_checker = re.compile(r"\d")
app = Flask(__name__)

app.secret_key = "NotSecret"


@app.route("/")
def pre_registration():
    return render_template("Carlos_RegistrationFormHTML_0514.html")


@app.route("/process", methods=["post"])
def process_request():
    all_okay = True
    if len(request.form["first_name"]) < 1:
        flash(u"First Name cannot be empty!", "error")
        all_okay = False

    if len(request.form["last_name"]) < 1:
        flash(u"Last Name cannot be empty!", "error")
        all_okay = False

    if len(request.form["email"]) < 1:
        flash(u"Email cannot be empty!", "error")
        all_okay = False
    elif not EMAIL_REGEX.match(request.form["email"]):
        flash(u"Invalid Email Address!", "error")
        all_okay = False

    if len(request.form["password"]) < 9:
        flash(u"Password cannot be empty and require 8 or more characters!", "error")
        all_okay = False

    if upper_checker.search(request.form["password"]) is None:
        flash(u"Passwords require at least one uppercase character!", "error")
        all_okay = False

    if number_checker.search(request.form["password"]) is None:
        print(request.form["password"])
        flash(u"Passwords require at least one numerical value!", "error")
        all_okay = False

    if len(request.form["password_confirmation"]) < 1:
        flash(u"Password confirmation cannot be empty!", "error")
        all_okay = False

    if request.form["password"] != request.form["password_confirmation"]:
        flash(u"Passwords do not match! Please have matching passwords.", "error")
        all_okay = False
    # print(strftime("%Y"))
    # print(request.form["birthday"][8:10])
    if request.form["birthday"][:4] >= strftime("%Y") and request.form["birthday"][5:7] >= strftime("%m") and \
                    request.form["birthday"][8:10] >= strftime("%d"):
        flash(u"Your birthday cannot be from the future!", "error")


    if all_okay:
        flash(u"Thanks for submitting your information!", "success")

    return redirect("")


app.run(debug=True)